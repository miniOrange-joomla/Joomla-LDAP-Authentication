<?php
defined('_JEXEC') or die;

class PlgSystemMiniorangedirsyncInstallerScript
{
	public function preflight($type, $parent)
	{
		if ($type === 'uninstall')
		{
			require_once __DIR__ . '/miniorangedirsync.php';

			$eid = (is_object($parent) && isset($parent->extension->extension_id))
				? (int) $parent->extension->extension_id : 0;

			PlgSystemMiniorangedirsync::triggerUninstallFeedback($eid);
		}

		return true;
	}
}
