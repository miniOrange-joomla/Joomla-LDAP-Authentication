<?php
defined('_JEXEC') or die;

/**
 * Component install script — uninstall feedback before removal.
 */
class ComMiniorangeDirsyncInstallerScript
{
	public function preflight($type, $parent)
	{
		if ($type === 'uninstall')
		{
			$this->runFeedback($parent);
		}

		return true;
	}

	private function runFeedback($parent)
	{
		$systemPlugin = JPATH_PLUGINS . '/system/miniorangedirsync/miniorangedirsync.php';

		if (!is_file($systemPlugin))
		{
			return;
		}

		require_once $systemPlugin;

		$eid = (is_object($parent) && isset($parent->extension->extension_id))
			? (int) $parent->extension->extension_id : 0;

		PlgSystemMiniorangedirsync::triggerUninstallFeedback($eid);
	}
}
