<?php
/**
 * @package     Joomla.Component
 * @subpackage  com_miniorange_dirsync
 *
 * @author      miniOrange Security Software Pvt. Ltd.
 * @copyright   Copyright (C) 2015 miniOrange (https://www.miniorange.com)
 * @license     GNU General Public License version 3; see LICENSE.txt
 * @contact     info@xecurify.com
 *
 * This class contains all the utility functions
 *
 **/
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;

if (!class_exists('MoDatabaseHelper', false))
{
	$dbHelperPath = dirname(__FILE__) . '/DatabaseHelper.php';

	if (is_file($dbHelperPath))
	{
		require_once $dbHelperPath;
	}
	else
	{
		class MoDatabaseHelper
		{
			public static function getDb()
			{
				if (method_exists(Factory::class, 'getContainer'))
				{
					try
					{
						return Factory::getContainer()->get(DatabaseInterface::class);
					}
					catch (\Throwable $e)
					{
						// Fall through.
					}
				}

				return Factory::getDbo();
			}
		}
	}
}

class MoLdapUtility
{

	public static function moLdapIsCustomerRegistered()
	{

		$result = self::moLdapFetchData('#__miniorange_ldap_customer', array('id' => '1'), 'loadAssoc');

		$email = $result['email'];
		$customerKey = $result['customer_key'];
		$status = $result['registration_status'];

		if ($email && $customerKey && is_numeric(trim($customerKey)) && $status == 'SUCCESS')
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	public static function moLdapCheckEmptyOrNull( $value )
	{
		if (! isset($value) || empty($value))
		{
			return true;
		}

		return false;
	}

	public static function moLdapIsCurlInstalled()
	{
		if (in_array('curl', get_loaded_extensions()))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	public static function moLdapGetHostname()
	{
		return 'https://login.xecurify.com';
	}

	public static function moLdapGetPluginVersion()
	{
		$db = MoDatabaseHelper::getDb();
		$dbQuery = $db->getQuery(true)
			->select('manifest_cache')
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('element') . "=" . $db->quote('com_miniorange_dirsync'));
		$db->setQuery($dbQuery);
		$manifest = json_decode($db->loadResult());

		return($manifest->version);
	}

	public static function getJoomlaCmsVersion()
	{
		try
		{
			// Use the official Joomla CMS Version class (recommended method)
			$version = new \Joomla\CMS\Version;

			return $version->getShortVersion();
		}
		catch (Exception $e)
		{
			// Fallback: try to get from JVERSION constant (Joomla 3.x compatibility)
			if (defined('JVERSION'))
			{
				return JVERSION;
			}

			// Final fallback
			return 'Unknown';
		}
	}

	/**
	 * Get the application input object across Joomla 3–6.
	 *
	 * @param   object|null  $app  Optional application instance.
	 *
	 * @return  object
	 */
	public static function moLdapGetApplicationInput($app = null)
	{
		if ($app === null)
		{
			$app = Factory::getApplication();
		}

		if (method_exists($app, 'getInput'))
		{
			return $app->getInput();
		}

		return $app->input;
	}

	/**
	 * Get the current user across Joomla 3 (JUser via Factory::getUser) and Joomla 4+ (User identity).
	 *
	 * @param   object|null  $app  Optional CMSApplication instance.
	 *
	 * @return  \Joomla\CMS\User\User|\JUser
	 */
	public static function moLdapGetApplicationUser($app = null)
	{
		if ($app === null)
		{
			$app = Factory::getApplication();
		}

		if (method_exists($app, 'getIdentity'))
		{
			return $app->getIdentity();
		}

		return Factory::getUser();
	}

	public static function moLdapEncrypt($str)
	{
		if ($str === null || $str === '')
		{
			return '';
		}

		if (!self::moLdapIsExtensionInstalled('openssl'))
		{
			return '';
		}

		$key = self::moLdapGetEncryptionKey();
		$iv = random_bytes(16);
		$ciphertext = openssl_encrypt($str, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);

		if ($ciphertext === false)
		{
			return '';
		}

		return 'v2:' . base64_encode($iv . $ciphertext);
	}

	public static function moLdapDecrypt($value)
	{
		if ($value === null || $value === '')
		{
			return '';
		}

		if (!self::moLdapIsExtensionInstalled('openssl'))
		{
			return '';
		}

		if (is_string($value) && strpos($value, 'v2:') === 0)
		{
			$payload = base64_decode(substr($value, 3), true);

			if ($payload === false || strlen($payload) <= 16)
			{
				return '';
			}

			$iv = substr($payload, 0, 16);
			$ciphertext = substr($payload, 16);
			$string = openssl_decrypt($ciphertext, 'aes-256-cbc', self::moLdapGetEncryptionKey(), OPENSSL_RAW_DATA, $iv);

			return $string === false ? '' : $string;
		}

		$legacyKey = 99189;
		$string = rtrim(openssl_decrypt(base64_decode($value), 'aes-128-ecb', $legacyKey, OPENSSL_RAW_DATA), "\0");

		return trim($string, "\0..\32");
	}

	/**
	 * Derive encryption key from the Joomla site secret (not stored in source).
	 *
	 * @return string
	 */
	private static function moLdapGetEncryptionKey()
	{
		$secret = Factory::getApplication()->get('secret');

		return hash('sha256', $secret . 'miniorange_ldap_storage', true);
	}

	/**
	 * Whether the IP/username pair is temporarily blocked after failed attempts.
	 *
	 * @param   string  $ipAddress  Client IP address.
	 * @param   string  $username   Login username.
	 *
	 * @return boolean
	 */
	public static function moLdapIsLoginBlocked($ipAddress, $username)
	{
		$loginAttemptData = self::moLdapFetchData(
			'#__mo_ldap_login_attempts',
			array('ip_address' => $ipAddress, 'username' => $username)
		);

		if (!$loginAttemptData)
		{
			return false;
		}

		$userLoginAttempts = (int) $loginAttemptData['user_login_attempts'];
		$userBlockedUntil = $loginAttemptData['blocked_until'];
		$currentTime = date('Y-m-d H:i:s');

		return $userLoginAttempts >= 5
			&& !empty($userBlockedUntil)
			&& strtotime($currentTime) < strtotime($userBlockedUntil);
	}

	/**
	 * Record a failed login and apply lockout after five attempts.
	 *
	 * @param   string  $ipAddress  Client IP address.
	 * @param   string  $username   Login username.
	 *
	 * @return void
	 */
	public static function moLdapRecordFailedLoginAttempt($ipAddress, $username)
	{
		$db = MoDatabaseHelper::getDb();
		$loginAttemptData = self::moLdapFetchData(
			'#__mo_ldap_login_attempts',
			array('ip_address' => $ipAddress, 'username' => $username)
		);
		$currentTime = date('Y-m-d H:i:s');
		$attempts = 1;
		$blockedUntil = null;

		if ($loginAttemptData)
		{
			$attempts = (int) $loginAttemptData['user_login_attempts'] + 1;
			$blockedUntil = null;

			if ($attempts >= 5)
			{
				$blockedUntil = date('Y-m-d H:i:s', strtotime('+30 minutes'));
			}

			self::moLdapUpdateData(
				'#__mo_ldap_login_attempts',
				array(
					'user_login_attempts' => $attempts,
					'blocked_until' => $blockedUntil,
					'last_attempt' => $currentTime,
				),
				array('ip_address' => $ipAddress, 'username' => $username)
			);

			return;
		}

		if ($attempts >= 5)
		{
			$blockedUntil = date('Y-m-d H:i:s', strtotime('+30 minutes'));
		}

		$query = $db->getQuery(true)
			->insert($db->quoteName('#__mo_ldap_login_attempts'))
			->columns(array(
				$db->quoteName('username'),
				$db->quoteName('ip_address'),
				$db->quoteName('user_login_attempts'),
				$db->quoteName('blocked_until'),
				$db->quoteName('last_attempt'),
				)
			)
			->values(
				$db->quote($username) . ', '
				. $db->quote($ipAddress) . ', '
				. (int) $attempts . ', '
				. ($blockedUntil === null ? 'NULL' : $db->quote($blockedUntil)) . ', '
				. $db->quote($currentTime)
			);
		$db->setQuery($query);
		$db->execute();
	}

	/**
	 * Clear failed-login counters after a successful authentication.
	 *
	 * @param   string  $ipAddress  Client IP address.
	 * @param   string  $username   Login username.
	 *
	 * @return void
	 */
	public static function moLdapClearLoginAttempts($ipAddress, $username)
	{
		$loginAttemptData = self::moLdapFetchData(
			'#__mo_ldap_login_attempts',
			array('ip_address' => $ipAddress, 'username' => $username)
		);

		if (!$loginAttemptData)
		{
			return;
		}

		self::moLdapUpdateData(
			'#__mo_ldap_login_attempts',
			array(
				'user_login_attempts' => 0,
				'blocked_until' => date('Y-m-d H:i:s', strtotime('+1 year')),
				'last_attempt' => date('Y-m-d H:i:s'),
			),
			array('ip_address' => $ipAddress, 'username' => $username)
		);
	}


	public static function moLdapIsExtensionInstalled($extensionName)
	{
		if (in_array($extensionName, get_loaded_extensions()))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	public static function moLdapErrorType($errorNumber)
	{

		if (-1 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_ENTER_VALID_URL');

			return $message;
		}

		if (0 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_SUCCESSFUL_CONNECTION');

			return $message;
		}

		if (2 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_INVALID_RESPONSE');

			return $message;
		}

		if ((3 == $errorNumber) || (10301 == $errorNumber))
		{
			$message = Text::_('COM_MINIORANGE_TIMELIMIT_EXCEEDED');

			return $message;
		}

		if (4 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_SIZELIMIT_EXCEEDED');

			return $message;
		}

		if (7 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_AUTHENTICATION_NOTSUPPORTED');

			return $message;
		}

		if (11 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_SERVERLIMIT_EXCEEDED');

			return $message;
		}

		if (49 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_ENTER_VALID_CREDENTIALS');

			return $message;
		}

		if (51 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_LDAP_SERVER_BUSY');

			return $message;
		}

		if (52 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_CANNOT_CONNECT_TO_SERVER');

			return $message;
		}

		if (10302 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_SERVER_REFUSED_CONNECTION');

			return $message;
		}

		if (10500 == $errorNumber)
		{
				   $message = Text::_('COM_MINIORANGE_CHECK_SEARCH_FILTER');

			return $message;
		}

		if (10305 == $errorNumber)
		{
				   $message = Text::_('COM_MINIORANGE_CHECK_HOSTNAME');

			return $message;
		}

		if (13 == $errorNumber)
		{
				$message = Text::_('COM_MINIORANGE_SECURE_SESSION');

			return $message;
		}

		if (34 == $errorNumber)
		{
			$message = Text::_('COM_MINIORANGE_CHECK_DN_SYNTAX');

			return $message;
		}

		$message = Text::_('COM_MINIORANGE_CONNECTION_FAILED');

		return $message;

	}
	public static function getUserGroupName($groupId)
	{
		$db = MoDatabaseHelper::getDb();
		$query = $db->getQuery(true)
			->select($db->quoteName('title'))
			->from($db->quoteName('#__usergroups'))
			->where($db->quoteName('id') . ' = ' . (int) $groupId);

		$db->setQuery($query);

		return $db->loadResult() ?: 'Unknown Group';
	}

	/**
	 * Update user_already_exist column to 1 if it's currently 0
	 *
	 * @param int $userId The user's ID
	 * @return bool True if updated, false otherwise
	 */
	public static function updateUserAlreadyExist($userId): bool
	{
		// Get the database object
		$db = MoDatabaseHelper::getDb();

		// Query to get the current value of 'user_already_exist' for the user
		$query = $db->getQuery(true);
		$query->select($db->quoteName('user_already_exist'))
			->from($db->quoteName('#__users'))
			->where($db->quoteName('id') . ' = ' . (int) $userId);

		$db->setQuery($query);
		$currentValue = (int) $db->loadResult();

		// If the current value is 0, update it to 1
		if ($currentValue === 0)
		{
			$query = $db->getQuery(true);
			$query->update($db->quoteName('#__users'))
				->set($db->quoteName('user_already_exist') . ' = 1')
				->where($db->quoteName('id') . ' = ' . (int) $userId);

			$db->setQuery($query);

			// Return whether the execution was successful
			return $db->execute();
		}

		// No update needed if current value is not 0
		return false;
	}

	public static function moLdapGetJoomlaGroups()
	{

		$db = MoDatabaseHelper::getDb();
		$db->setQuery($db->getQuery(true)
			->select('*')
			->from("#__usergroups")
		);

		return $db->loadRowList();
	}

	public static function moLdapUpdateData($tableName,$tableFields,$tableConditions)
	{

		$db = MoDatabaseHelper::getDb();
		$query = $db->getQuery(true);
		$sanFields = array();

		foreach ($tableFields as $key => $value)
		{
			if ($value === null)
			{
				array_push($sanFields, $db->quoteName($key) . ' = NULL');
			}
			else
			{
				array_push($sanFields, $db->quoteName($key) . ' = ' . $db->quote($value));
			}
		}

		$sanConditions = array();

		foreach ($tableConditions as $key => $value)
		{
			array_push($sanConditions, $db->quoteName($key) . '=' . $db->quote($value));
		}

		$query->update($db->quoteName($tableName))->set($sanFields)->where($sanConditions);
		$db->setQuery($query);
		$db->execute();

	}

	public static function moLdapFetchData($tableName,$condition=true,$method='loadAssoc',$columns='*')
	{

		$db = MoDatabaseHelper::getDb();
		$query = $db->getQuery(true);
		$columns = is_array($columns) ? $db->quoteName($columns) : $columns;
		$query->select($columns);
		$query->from($db->quoteName($tableName));

		if ($condition !== true)
		{
			foreach ($condition as $key => $value)
			{
				$query->where($db->quoteName($key) . "=" . $db->quote($value));
			}
		}

		$db->setQuery($query);

		if ($method == 'loadColumn')
		{
			return $db->loadColumn();
		}
		elseif ($method == 'loadObjectList')
		{
			return $db->loadObjectList();
		}
		elseif ($method == 'loadObject')
		{
			return $db->loadObject();
		}
		elseif ($method == 'loadResult')
		{
			return $db->loadResult();
		}
		elseif ($method == 'loadRow')
		{
			return $db->loadRow();
		}
		elseif ($method == 'loadRowList')
		{
			return $db->loadRowList();
		}
		elseif ($method == 'loadAssocList')
		{
			return $db->loadAssocList();
		}
		else
		{
			return $db->loadAssoc();
		}
	}

	public static function moLdapGetOperatingSystem()
	{

		if (isset($_SERVER))
		{
			$userAgent = $_SERVER['HTTP_USER_AGENT'];
		}
		elseif (isset($GLOBALS['HTTP_SERVER_VARS']))
		{
			$userAgent = $GLOBALS['HTTP_SERVER_VARS']['HTTP_USER_AGENT'];
		}
		else
		{
			$userAgent = $GLOBALS['HTTP_USER_AGENT'] ?? '';
		}

		$osArray = array(
			'windows nt 10' => 'Windows 10',
			'windows nt 6.3' => 'Windows 8.1',
			'windows nt 6.2' => 'Windows 8',
			'windows nt 6.1|windows nt 7.0' => 'Windows 7',
			'windows nt 6.0' => 'Windows Vista',
			'windows nt 5.2' => 'Windows Server 2003/XP x64',
			'windows nt 5.1' => 'Windows XP',
			'windows xp' => 'Windows XP',
			'windows nt 5.0|windows nt5.1|windows 2000' => 'Windows 2000',
			'windows me' => 'Windows ME',
			'windows nt 4.0|winnt4.0' => 'Windows NT',
			'windows ce' => 'Windows CE',
			'windows 98|win98' => 'Windows 98',
			'windows 95|win95' => 'Windows 95',
			'win16' => 'Windows 3.11',
			'mac os x 10.1[^0-9]' => 'Mac OS X Puma',
			'macintosh|mac os x' => 'Mac OS X',
			'mac_powerpc' => 'Mac OS 9',
			'linux' => 'Linux',
			'ubuntu' => 'Linux - Ubuntu',
			'iphone' => 'iPhone',
			'ipod' => 'iPod',
			'ipad' => 'iPad',
			'android' => 'Android',
			'blackberry' => 'BlackBerry',
			'webos' => 'Mobile',

			'(media center pc).([0-9]{1,2}\.[0-9]{1,2})' => 'Windows Media Center',
			'(win)([0-9]{1,2}\.[0-9x]{1,2})' => 'Windows',
			'(win)([0-9]{2})' => 'Windows',
			'(windows)([0-9x]{2})' => 'Windows',
			'Win 9x 4.90' => 'Windows ME',
			'(windows)([0-9]{1,2}\.[0-9]{1,2})' => 'Windows',
			'win32' => 'Windows',
			'(java)([0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2})' => 'Java',
			'(Solaris)([0-9]{1,2}\.[0-9x]{1,2}){0,1}' => 'Solaris',
			'dos x86' => 'DOS',
			'Mac OS X' => 'Mac OS X',
			'Mac_PowerPC' => 'Macintosh PowerPC',
			'(mac|Macintosh)' => 'Mac OS',
			'(sunos)([0-9]{1,2}\.[0-9]{1,2}){0,1}' => 'SunOS',
			'(beos)([0-9]{1,2}\.[0-9]{1,2}){0,1}' => 'BeOS',
			'(risc os)([0-9]{1,2}\.[0-9]{1,2})' => 'RISC OS',
			'unix' => 'Unix',
			'os/2' => 'OS/2',
			'freebsd' => 'FreeBSD',
			'openbsd' => 'OpenBSD',
			'netbsd' => 'NetBSD',
			'irix' => 'IRIX',
			'plan9' => 'Plan9',
			'osf' => 'OSF',
			'aix' => 'AIX',
			'GNU Hurd' => 'GNU Hurd',
			'(fedora)' => 'Linux - Fedora',
			'(kubuntu)' => 'Linux - Kubuntu',
			'(ubuntu)' => 'Linux - Ubuntu',
			'(debian)' => 'Linux - Debian',
			'(CentOS)' => 'Linux - CentOS',
			'(Mandriva).([0-9]{1,3}(\.[0-9]{1,3})?(\.[0-9]{1,3})?)' => 'Linux - Mandriva',
			'(SUSE).([0-9]{1,3}(\.[0-9]{1,3})?(\.[0-9]{1,3})?)' => 'Linux - SUSE',
			'(Dropline)' => 'Linux - Slackware (Dropline GNOME)',
			'(ASPLinux)' => 'Linux - ASPLinux',
			'(Red Hat)' => 'Linux - Red Hat',
			'(linux)' => 'Linux',
			'(amigaos)([0-9]{1,2}\.[0-9]{1,2})' => 'AmigaOS',
			'amiga-aweb' => 'AmigaOS',
			'amiga' => 'Amiga',
			'AvantGo' => 'PalmOS',
			'[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3})' => 'Linux',
			'(webtv)/([0-9]{1,2}\.[0-9]{1,2})' => 'WebTV',
			'Dreamcast' => 'Dreamcast OS',
			'GetRight' => 'Windows',
			'go!zilla' => 'Windows',
			'gozilla' => 'Windows',
			'gulliver' => 'Windows',
			'ia archiver' => 'Windows',
			'NetPositive' => 'Windows',
			'mass downloader' => 'Windows',
			'microsoft' => 'Windows',
			'offline explorer' => 'Windows',
			'teleport' => 'Windows',
			'web downloader' => 'Windows',
			'webcapture' => 'Windows',
			'webcollage' => 'Windows',
			'webcopier' => 'Windows',
			'webstripper' => 'Windows',
			'webzip' => 'Windows',
			'wget' => 'Windows',
			'Java' => 'Unknown',
			'flashget' => 'Windows',
			'MS FrontPage' => 'Windows',
			'(msproxy)/([0-9]{1,2}.[0-9]{1,2})' => 'Windows',
			'(msie)([0-9]{1,2}.[0-9]{1,2})' => 'Windows',
			'libwww-perl' => 'Unix',
			'UP.Browser' => 'Windows CE',
			'NetAnts' => 'Windows',
		);

		$archRegex = '/\b(x86_64|x86-64|Win64|WOW64|x64|ia64|amd64|ppc64|sparc64|IRIX64)\b/ix';
		$arch = preg_match($archRegex, $userAgent) ? '64' : '32';

		foreach ($osArray as $regex => $value)
		{
			if (preg_match('{\b(' . $regex . ')\b}i', $userAgent))
			{
				return $value . ' x' . $arch;
			}
		}

		return 'Unknown';
	}


	public static function convertBinaryToString($input)
	{
		if (is_string($input) && !mb_detect_encoding($input, 'utf-8', true))
		{
			// Convert binary to base64
			return base64_encode($input);
		}

		return $input;
	}

	public static function buildLdapAttributeOptions(array $receivedAttributes = array()): array
	{
		require_once dirname(__FILE__) . '/MoConstants.php';

		$options = MoConstants::LDAP_SERVER_ATTRIBUTES;

		foreach ($receivedAttributes as $attribute)
		{
			$key = strtolower((string) $attribute);

			if ($key !== '' && !isset($options[$key]))
			{
				$options[$key] = $key;
			}
		}

		return $options;
	}

	public static function formatLdapAttributeValue($attribute, $value)
	{
		$attribute = strtolower((string) $attribute);

		if ($attribute === 'objectguid' || $attribute === 'objectsid')
		{
			if (is_array($value) && isset($value['count']))
			{
				$formatted = array();

				for ($i = 0; $i < $value['count']; $i++)
				{
					if (isset($value[$i]))
					{
						$formatted[] = self::convertBinaryToString($value[$i]);
					}
				}

				return $formatted;
			}

			return self::convertBinaryToString($value);
		}

		return $value;
	}

	public static function saveTestAuthenticationAttributes($username, $password)
	{
		require_once dirname(__FILE__) . '/MoConstants.php';
		require_once dirname(__FILE__) . '/dirsync_ldap_config.php';

		$authResponse = MoLdapConfig::moLdapAuthenticateUser(trim($username), $password);

		if ($authResponse->statusMessage !== 'SUCCESS')
		{
			return $authResponse;
		}

		$userAttributes = MoLdapConfig::moLdapGetUserDetails(trim($username));

		if ($userAttributes && is_array($userAttributes) && isset($userAttributes[0]))
		{
			$authResponse->attributeList = $userAttributes[0];
		}
		else
		{
			$authResponse->attributeList = array();
		}

		$attributeList = array();

		foreach ($authResponse->attributeList as $attribute => $value)
		{
			if (is_numeric($attribute) || $attribute === 'count')
			{
				continue;
			}

			$attributeList[] = $attribute;
		}

		$adUserDetails = array_map(array(self::class, 'convertBinaryToString'), $authResponse->attributeList ?: array());
		$userDetails = array(
			'Name' => $username,
			'Details' => json_encode($adUserDetails, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE),
		);

		self::moLdapUpdateData(
			'#__miniorange_dirsync_config',
			array(
				'ad_attribute_list' => json_encode($attributeList),
				'ldap_login' => 'ch',
				'test_config_details' => json_encode($userDetails),
			),
			array('id' => '1')
		);

		return $authResponse;
	}

	public static function exportData($tableNames)
	{
		$db = MoDatabaseHelper::getDb();
		$jsonData = array();
		$decryptFields = array(
			'#__miniorange_dirsync_config' => array(
				'ldap_server_url',
				'service_account_dn',
				'service_account_password',
				'search_base',
			),
		);

		if (empty($tableNames))
		{
			$jsonData['error'] = 'No table names provided.';
		}
		else
		{
			foreach ($tableNames as $tableName)
			{
				$query = $db->getQuery(true);
				$query->select('*')
					->from($db->quoteName($tableName));

				$db->setQuery($query);

				try
				{
					$data = $db->loadObjectList();

					if (empty($data))
					{
						$jsonData[$tableName] = array('message' => 'This table is empty.');
					}
					else
					{
						if (isset($decryptFields[$tableName]))
						{
							foreach ($data as $row)
							{
								foreach ($decryptFields[$tableName] as $field)
								{
									if ($field === 'service_account_password')
									{
										$row->$field = '';

										continue;
									}

									if (isset($row->$field) && $row->$field !== '')
									{
										$row->$field = self::moLdapDecrypt($row->$field);
									}
								}
							}
						}

						$jsonData[$tableName] = $data;
					}
				}
				catch (Exception $e)
				{
					$jsonData[$tableName] = array('error' => $e->getMessage());
				}
			}
		}

		// Generate filename with timestamp
		$filename = 'ldap_configuration_' . date('Y-m-d_H-i-s') . '.json';

		while (ob_get_level())
		{
			ob_end_clean();
		}

		$jsonOutput = json_encode($jsonData, JSON_PRETTY_PRINT);

		header("Content-Disposition: attachment; filename=\"{$filename}\"");
		header('Content-Type: application/json; charset=utf-8');
		header('Content-Length: ' . strlen($jsonOutput));

		echo $jsonOutput;
		exit;
	}

	public static function moLdapIsPluginEnabled($folder, $element)
	{
		$db = MoDatabaseHelper::getDb();
		$query = $db->getQuery(true)
			->select($db->quoteName('enabled'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
			->where($db->quoteName('folder') . ' = ' . $db->quote($folder))
			->where($db->quoteName('element') . ' = ' . $db->quote($element));

		$db->setQuery($query);

		return (bool) $db->loadResult();
	}

	public static function moLdapGetDetails(string $tablename)
	{
		$db = MoDatabaseHelper::getDb();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from($db->quoteName($tablename));
		$query->where($db->quoteName('id') . " = 1");

		$db->setQuery($query);
		$customerDetails = $db->loadAssoc();

		return $customerDetails;
	}
}

